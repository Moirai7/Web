ThinkCMF默认模板，主要用于基础功能演示

### 更新日志
#### 1.0.2
* 规范 jq,和 wind.js 引入
* 更改 comment钩子参数
